# Html5_Tetris #

Html5_Tetris is a clone of the famous Tetris game written in Javascript using some of the new HTML5 API

The code is 100% Javascript and distributed under the GPL v3 license.

It use some external library:
MooTools (http://mootools.net)
Modernizr (httpp://modernizr.com)

PS: The license is being check to avoid conflict with third party library

Kaiserbaldo (kaiserbaldo@gmail.com)
